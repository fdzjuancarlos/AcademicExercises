#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import Ice
Ice.loadSlice('-I {} cannon.ice'.format(Ice.getSliceDir()))
import Cannon


class Client(Ice.Application):
	def run(self, argv):
		A = Cannon.Matrix(2,list([1,2,3,4]))
		proxy = self.communicator().stringToProxy(argv[1])
		
		processor = Cannon.ProcessorPrx.checkedCast(proxy)

		if not processor:
			raise RuntimeError('Invalid proxy')

		processor.injectA(A,0)
		processor.injectB(A,0)


		return 0
		



sys.exit(Client().main(sys.argv))
