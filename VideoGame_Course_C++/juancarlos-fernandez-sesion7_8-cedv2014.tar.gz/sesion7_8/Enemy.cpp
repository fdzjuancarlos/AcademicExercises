
//	class Enemy : public Entity3D{
//		int _hp;
//	public:
//		Enemy(std::string name,int x,int y,int z,int hp);
//		int getHp();
//	};

#include "Enemy.h"

Enemy::Enemy(std::string name,int x,int y,int z,int hp) : Entity3D(name,x,y,z){
	_hp=hp;
}

int Enemy::getHp(){
	return _hp;
}

