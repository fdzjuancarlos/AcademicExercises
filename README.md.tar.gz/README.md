AcademicExercises
=================
